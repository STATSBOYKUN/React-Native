import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const Pesanan = () => {
    return (
        <View>
            <Text>Pesanan</Text>
        </View>
    )
}

export default Pesanan

const styles = StyleSheet.create({})
