import Home from './Home'
import Akun from './Akun'
import Pesanan from './Pesanan'
import Splash from './Splash'


export { Splash, Pesanan, Akun, Home }